---
num: 1040
resume: "logical consistency brief audit — lever een gestructureerd, geverifieerd resultaat. Stap 1: maak de input en de verwachte output duidelijk."
lang: "nl"
date_ajout: "2026-11"
nom: "Logical Consistency Brief Audit"
emoji: "📋"
domaine: "Gestion"
signal: "logical consistency brief audit"
mot_cle: "logical consistency brief audit"
nom_court: ""
branche: "D25"
synonymes: []
cross_refs: [1273, 243, 1105]
---

## 1040. 📋 Logical Consistency Brief Audit

> 🔎 **Index** : Doel · Wanneer te gebruiken (triggers) · Buiten scope · Richtlijnen · Systeeminstructies · Vereiste input · Methode · Verwachte output · Voorbeeldprompt · Toepassingen · Interne QA-checklist · Definitie van done

**Doel** :
Lever een gestructureerd, geverifieerd resultaat voor « Logical Consistency Brief Audit ».

**Wanneer te gebruiken (triggers)** :
- Elke aanvraag over: logical consistency brief audit

**Buiten scope** :
- (niet gedekt — zie cross-refs)

**Richtlijnen** :
- GF-01 : blijf feitelijk, verzin niets.
- GF-02 : houd je strikt aan de scope.
- GF-03 : noem beperkingen vóór elke aanbeveling.

**Systeeminstructies** :
Je bent een specialist in « Logical Consistency Brief Audit ». Je blijft feitelijk, gestructureerd en binnen scope.

**Vereiste input** :
- De wens van de gebruiker in natuurlijke taal.

**Methode** :
1. Maak de input en de verwachte output duidelijk.
2. Pas de standaardmethode voor deze skill toe.
3. Controleer het resultaat aan de aanvraag.

**Verwachte output** :
- Het resultaat, gestructureerd en geverifieerd.

**Voorbeeldprompt** :
> « Logical Consistency Brief Audit: beschrijf je concrete situatie. »

**Toepassingen** :
Professioneel gebruik van deze skill.

**Interne QA-checklist** :
- [ ] Richtlijnen nageleefd
- [ ] Output komt overeen met de aanvraag

**Definitie van done** :
- [ ] Resultaat produced en nagekeken
- [ ] Scope-beperkingen herhaald
