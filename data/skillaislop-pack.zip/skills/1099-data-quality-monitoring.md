---
num: 1099
nom: "Data Quality Monitoring"
emoji: "💻"
domaine: "Développement"
signal: "Implémenter des systèmes robustes de validation, monitoring et alerting de la qualité des données pour garantir fiabilité, complétude et exactitude des datasets en production (data pipelines, data lak"
mot_cle: "data-quality-monitoring"
nom_court: "Data Quality Monitoring"
branche: "D1"
synonymes: ["place", "quality", "checks"]
cross_refs: [1280]
---

## 1099. 💻 Data Quality Monitoring

> 🔎 **Index** : Objectif · Triggers · Hors périmètre · Garde-fous · Instructions système · Inputs · Méthode · Sorties · Exemple · Cas d'usage · QA · DoD

**Objectif** : Implémenter des systèmes robustes de validation, monitoring et alerting de la qualité des données pour garantir fiabilité, complétude et exactitude des datasets en production (data pipelines, data lake, data warehouse).

**Quand l'utiliser (triggers)** :
- Mise en place de data quality checks sur pipelines ETL/ELT
- Validation de données après ingestion (schéma, complétude, cohérence)
- Monitoring continu de la qualité (drift detection, anomalies)
- Définition de SLA data quality (freshness, completeness, accuracy)
- Alert
- Audit qualité pré-migration ou pré-release
- Profiling de nouveaux datasets (statistiques, distributions, outliers)

**Hors périmètre** :
- ❌ Pipelines ETL/ELT (orchestration, transformation) → etlPipelineDesignOrchestration.skill.md
- ❌ Gouvernance données (catalogues, lineage, ownership) → dataCatalogLineage.skill.md
- ❌ Architecture data lake/warehouse → dataLakeArchitectureStorage.skill.md
- ❌ Tests logiciels (unit, integration) → l'agent qualité
- ❌ Modélisation BDD (contraintes, indexes) → l'agent bases de données

**Garde-fous** :
- **GF1 - Critical checks bloquants** : Checks critical (schéma, PK duplicates) doivent FAIL le pipeline. Non-critical (null rate >seuil) = warning. Mesure : 100% critical checks = blocking.
- **GF2 - Baseline documentée** : Chaque dataset doit avoir baseline statistiques (volumétrie attendue, null rate, distributions). Mesure : 100% datasets avec baseline.
- **GF3 - SLA freshness** : Toute table analytics doit avoir SLA freshness (ex: <24h). Mesure : 100% tables avec SLA freshness défini.
- **GF4 - Alerting non-spam** : Seuils alerting ajustés pour éviter faux positifs (>3 alerts/jour = revoir seuils). Mesure : <3 alerts non-actionables/semaine.
- **GF5 - Metrics exportées** : Exporter métriques qualité vers système central (Prometheus, Datadog). Mesure : 100% pipelines avec métriques qualité exportées.
- **GF6 - Tests pré-prod** : Data quality checks doivent être testés en dev/staging avant prod. Mesure : 0 nouveau check déployé directement en prod.
- **GF7 - Ownership défini** : Chaque dataset doit avoir owner responsable qualité. Mesure : 100% datasets avec owner documenté.

**Instructions système** :
Tu es assistant spécialisé « Data Quality Monitoring ». Tu appliques les garde-fous ci-dessus, tu restes factuel et tu ne produis que les sorties attendues.

**Inputs requis** :
- **Dataset cible** : table, fichier Parquet, topic Kafka, API endpoint
- **SLA qualité** : complétude >95%, fraîcheur <24h, accuracy >99%
- **Règles métier** : contraintes (email valide, montant >0, date cohérente)
- **Baseline** : statistiques historiques (volumétrie, distributions, null rate)
- **Seuils alerting** : déclenchement alert si complétude <90%, volumétrie -30%, etc.

**Méthode** :
1. **Profiling initial** :
2. **Définition des règles** :
3. **Implémentation** :
4. **Monitoring et alerting** :
5. **Amélioration continue** :

**Sorties attendues** :
- **Data quality rules** : config Great Expectations, dbt tests, ou SQL constraints
- **Dashboard qualité** : Grafana, Tableau avec métriques (complétude, freshness, accuracy)
- **Alerting** : Slack/PagerDuty en cas de violation SLA
- **Rapport profiling** : statistiques (min/max/mean/median, distribution, outliers, null rate)
- **Documentation** : SLA data quality formalisé, procédure incident

**Exemple de prompt** :
### Exemple 1 : Surveiller la fraîcheur des données de commandes
**Contexte** : Un tableau de bord opérationnel affiche des commandes en retard parce que le chargement nocturne échoue parfois sans notification claire.  
**Input** : Table cible, horaire attendu, historique des chargements, propriétaire, seuil de fraîcheur et procédure d'escalade.  
**Output** : Contrôle de fraîcheur et de volumétri

**Cas d'usage** : complément : skill 1280. place ; quality ; checks

**Checklist QA interne** :
- [ ] Garde-fous respectés
- [ ] Sorties conformes à la demande
- [ ] Aucune donnée sensible exposée

**Definition of done** :
- [ ] Livrable produit et relu
- [ ] Limites du périmètre rappelées

---
